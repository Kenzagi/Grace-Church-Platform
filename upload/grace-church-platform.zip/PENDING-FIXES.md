# Grace Community Church — Pending UI/UX Fixes & Features

> Status as of October 2026. These items were identified during live testing of the Vercel deployment.

---

## 1. Empty Dropdown Placeholders

**Problem:** Select dropdowns (e.g., household, group assignments) show blank/null when no items are available, confusing users into thinking the dropdown is broken.

**Fix:** Add placeholder text like "No items available" or "No groups yet" to all Select components when the options list is empty. This should be applied to:
- Household selector in member form
- Group selector in membership assignment
- Speaker selector in media form
- Event selector in attendance form

**Files:** `src/components/sections/MembersSection.tsx`, `EventsAttendanceSection.tsx`, `MediaSubmissionsSection.tsx`

---

## 2. Easier Group Creation (Inline)

**Problem:** Creating a new group requires navigating to the "Manage Groups" dialog, which is buried and breaks the member editing workflow. Household creation already supports inline creation from the member form.

**Fix:** Add an inline "Create new group" option directly inside the group assignment Select dropdown in the member form, mirroring how household creation works:
- Add a "+" button or "Create new..." option at the top of the group dropdown
- On click, show a small inline form (name + category) within the dropdown popover
- On submit, create the group via API and auto-assign the member

**Files:** `src/components/sections/MembersSection.tsx`, `src/app/api/groups/route.ts`

---

## 3. Photo Upload Internal Server Error

**Problem:** Uploading a member photo via the member edit form returns an Internal Server Error (500).

**Likely cause:** The photo upload API route (`/api/members/[id]/photo`) may have issues with:
- File system write permissions for `public/uploads/members/`
- Missing `sharp` configuration for image processing
- Incorrect form data parsing in the route handler

**Fix:** Debug the `/api/members/[id]/photo/route.ts` endpoint:
- Verify the upload directory exists and is writable
- Ensure `sharp` properly processes the uploaded buffer
- Add proper error handling with user-friendly error messages
- Consider using Vercel Blob or Supabase Storage for production (filesystem uploads don't persist on Vercel)

**Files:** `src/app/api/members/[id]/photo/route.ts`, `src/components/sections/MembersSection.tsx`

---

## 4. Mouse Pointer Events on Clickable Elements

**Problem:** Several clickable/hoverable elements (buttons, links, cards, table rows, dropdown triggers) do not show the pointer cursor, making them feel non-interactive.

**Fix:** Audit all interactive elements and add `cursor-pointer` class:
- Table row click handlers (member rows, event rows, attendance rows)
- Card elements that are clickable
- Dropdown menu triggers
- Tab triggers
- Badge/tag click handlers
- Sidebar navigation items (verify they already have it)

**Files:** `src/components/sections/*.tsx`, `src/components/AppShell.tsx`, `src/components/shared.tsx`

---

## 5. Input Field Validation Enforcement

**Problem:** Marital status, date of birth, and gender fields are optional (nullable) in the schema and UI, but these values are needed for group assignment logic. Members can be created without these fields, causing issues downstream.

**Fix:**
- Make gender and marital status **required** fields in the member creation/edit form (add Zod validation)
- Make dateOfBirth strongly encouraged (add a visual warning if empty, but don't block submission)
- Update the Prisma schema `Member` model to make `gender` and `maritalStatus` non-nullable (requires migration)
- Update the CSV import validation to require these fields

**Schema change:**
```prisma
model Member {
  // ...
  dateOfBirth   DateTime           // was DateTime?
  gender        String             // was String? — "male" | "female" | "other"
  maritalStatus String             // was String? — "single" | "married" | "divorced" | "widowed"
  // ...
}
```

**Files:** `src/components/sections/MembersSection.tsx`, `src/lib/validations.ts`, `prisma/schema.prisma`, `src/app/api/members/route.ts`

---

## 6. Light Mode Contrast & Styling

**Problem:** In light mode, several UI elements have poor contrast:
- Input field backgrounds are nearly invisible against the page background
- Popover/dropdown backgrounds appear too light
- Unwanted grey backgrounds and shadows on cards
- Text contrast ratios fail accessibility standards (WCAG AA)

**Fix:**
- Review `globals.css` CSS variable overrides for light mode
- Ensure `--background`, `--card`, `--popover`, `--input` have sufficient contrast against `--foreground`
- Remove or reduce unwanted `shadow-sm` / grey backgrounds on cards in light mode
- Test all text sizes against WCAG AA contrast ratio (4.5:1 for normal text, 3:1 for large text)
- Verify popover and dropdown backgrounds in light mode

**Files:** `src/app/globals.css`, `src/components/ui/select.tsx`, `src/components/ui/popover.tsx`, `src/components/ui/input.tsx`

---

## Additional Pending Items (From Prior Sessions)

### CSV Import Upgrade
- Pre-import validation preview before committing
- Duplicate handling control (skip/overwrite/merge)
- Field-level validation with error highlighting

### Security Hardening
- Rate limiting on auth and write endpoints
- `middleware.ts` auth guard for protected routes
- Organization-scoping leak fixes in 5 API routes

### Validation Sweep
- 13 Zod schemas not yet applied to API routes
- Error message leaking (internal details exposed to client)
- Database transactions for multi-step writes (member + membership creation)
